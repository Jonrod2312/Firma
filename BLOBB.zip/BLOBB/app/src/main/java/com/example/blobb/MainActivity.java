package com.example.blobb;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.github.gcacace.signaturepad.views.SignaturePad;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private SignaturePad firma;
    private Button botonGuardar, botonBorrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firma = findViewById(R.id.signature_pad);
        botonGuardar = findViewById(R.id.boton_guardar);
        botonBorrar = findViewById(R.id.boton_borrar);

        botonGuardar.setOnClickListener(view -> {
            if (firma.isEmpty()) {
                Toast.makeText(MainActivity.this, "No hay firma para guardar", Toast.LENGTH_SHORT).show();
            } else {
                guardarFirma();  // Ya no se necesita verificarPermisos()
            }
        });

        botonBorrar.setOnClickListener(view -> firma.clear());
    }

    private void guardarFirma() {
        Bitmap imagenFirma = firma.getSignatureBitmap();
        File directorio = new File(getExternalFilesDir(null), "firmas");

        if (!directorio.exists()) {
            directorio.mkdirs();
        }

        String nombreArchivo = "firma_" + System.currentTimeMillis() + ".png";
        File archivo = new File(directorio, nombreArchivo);

        try {
            FileOutputStream fos = new FileOutputStream(archivo);
            imagenFirma.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
            Toast.makeText(this, "Firma guardada en:\n" + archivo.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Toast.makeText(this, "Error al guardar la firma", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}

