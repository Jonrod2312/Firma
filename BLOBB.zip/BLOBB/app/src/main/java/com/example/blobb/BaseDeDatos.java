package com.example.blobb;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BaseDeDatos extends SQLiteOpenHelper {

    public static final String NOMBRE_BD = "firmas.db";
    public static final int VERSION_BD = 1;

    public BaseDeDatos(Context context) {
        super(context, NOMBRE_BD, null, VERSION_BD);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE firmas (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "descripcion TEXT, " +
                        "firma BLOB)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int versionAntigua, int versionNueva) {
        db.execSQL("DROP TABLE IF EXISTS firmas");
        onCreate(db);
    }
}

