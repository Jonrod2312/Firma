package com.example.blobb;

public class Firma {
    private int id;
    private String descripcion;
    private byte[] firmaDigital;

    public Firma(int id, String descripcion, byte[] firmaDigital) {
        this.id = id;
        this.descripcion = descripcion;
        this.firmaDigital = firmaDigital;
    }

    public int getId() { return id; }
    public String getDescripcion() { return descripcion; }
    public byte[] getFirmaDigital() { return firmaDigital; }

    public void setId(int id) { this.id = id; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public void setFirmaDigital(byte[] firmaDigital) { this.firmaDigital = firmaDigital; }
}

