package com.example.blobb;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class FirmasBD {

    private BaseDeDatos bd;

    public FirmasBD(Context contexto) {
        bd = new BaseDeDatos(contexto);
    }

    public long guardarFirma(String descripcion, byte[] firmaDigital) {
        SQLiteDatabase db = bd.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("descripcion", descripcion);
        valores.put("firma", firmaDigital);
        return db.insert("firmas", null, valores);
    }

    public ArrayList<Firma> obtenerTodasLasFirmas() {
        ArrayList<Firma> lista = new ArrayList<>();
        SQLiteDatabase db = bd.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM firmas", null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String descripcion = cursor.getString(1);
                byte[] firma = cursor.getBlob(2);
                lista.add(new Firma(id, descripcion, firma));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return lista;
    }
}

