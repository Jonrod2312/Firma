package com.example.blobb;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class AdaptadorFirmas extends RecyclerView.Adapter<AdaptadorFirmas.FirmaViewHolder> {

    private Context contexto;
    private ArrayList<Firma> listaFirmas;

    public AdaptadorFirmas(Context contexto, ArrayList<Firma> listaFirmas) {
        this.contexto = contexto;
        this.listaFirmas = listaFirmas;
    }

    @Override
    public FirmaViewHolder onCreateViewHolder(ViewGroup padre, int viewType) {
        View vista = LayoutInflater.from(contexto).inflate(R.layout.item_firma, padre, false);
        return new FirmaViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(FirmaViewHolder holder, int posicion) {
        Firma firma = listaFirmas.get(posicion);
        holder.textoDescripcion.setText(firma.getDescripcion());

        Bitmap bitmap = BitmapFactory.decodeByteArray(firma.getFirmaDigital(), 0, firma.getFirmaDigital().length);
        holder.imagenFirma.setImageBitmap(bitmap);
    }

    @Override
    public int getItemCount() {
        return listaFirmas.size();
    }

    public static class FirmaViewHolder extends RecyclerView.ViewHolder {
        ImageView imagenFirma;
        TextView textoDescripcion;

        public FirmaViewHolder(View itemView) {
            super(itemView);
            imagenFirma = itemView.findViewById(R.id.imagenFirma);
            textoDescripcion = itemView.findViewById(R.id.textoDescripcion);
        }
    }
}
